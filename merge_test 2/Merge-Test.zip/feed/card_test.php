<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="feedCard container-fluid d-flex">
        <div class="cardUserImg">
            <img src="https://upload.wikimedia.org/wikipedia/vi/f/f5/Dua_Lipa_-_Future_Nostalgia_%28Official_Album_Cover%29.png">
        </div>

        <div class="cardInfos container-fluid">
            <div class="d-flex">
                <h3>Dua Lipa talking about Loki</h3>
            </div>

            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Rerum placeat quod accusantium doloremque fugiat, vel saepe beatae esse magnam adipisci, repudiandae vitae? Adipisci, velit! Ut voluptates unde eaque eius accusamus.
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Culpa rem adipisci pariatur consectetur neque deserunt. Itaque nulla numquam corporis libero quia nisi minus. Officiis quis impedit iusto veniam, sapiente iste.
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis sed, accusantium autem facere quod praesentium perspiciatis, enim eaque modi sit excepturi. Molestiae praesentium nostrum laboriosam rerum voluptatum hic minima facere.
            </p>      
                 
            <img src="https://www.thenews.com.pk/assets/uploads/updates/2021-03-23/808566_7137929_dua-lipa234_updates.jpg">
        </div>
    </div>
</body>
</html>